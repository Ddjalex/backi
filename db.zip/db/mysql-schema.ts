import { sql } from "drizzle-orm";
import { boolean, datetime, decimal, int, json, mysqlTable, text, varchar, mysqlEnum } from "drizzle-orm/mysql-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = mysqlTable("users", {
  id: int("id").primaryKey().autoincrement(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 50 }),
  role: mysqlEnum("role", ["admin", "editor", "agent"]).notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Properties table
export const properties = mysqlTable("properties", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  description: text("description").notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  propertyType: mysqlEnum("property_type", ["apartment", "house", "commercial", "shop", "land"]).notNull(),
  bedrooms: int("bedrooms"),
  bathrooms: int("bathrooms"),
  sizeSqm: decimal("size_sqm", { precision: 10, scale: 2 }).notNull(),
  priceETB: decimal("price_etb", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["active", "draft", "sold", "rented"]).notNull().default("draft"),
  featured: boolean("featured").default(false),
  amenities: json("amenities").$type<string[]>().default([]),
  images: json("images").$type<string[]>().default([]),
  imageCount: int("image_count").default(0),
  projectId: int("project_id"),
  coordinates: json("coordinates").$type<{ lat: number; lng: number }>(),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").default(sql`CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`),
});

// Projects table
export const projects = mysqlTable("projects", {
  id: int("id").primaryKey().autoincrement(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description").notNull(),
  images: json("images").$type<string[]>().default([]),
  delivered: boolean("delivered").default(false),
  location: varchar("location", { length: 255 }).notNull(),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Construction Updates table
export const constructionUpdates = mysqlTable("construction_updates", {
  id: int("id").primaryKey().autoincrement(),
  projectId: int("project_id").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  body: text("body").notNull(),
  images: json("images").$type<string[]>().default([]),
  progressPercent: int("progress_percent").notNull(),
  publishedAt: datetime("published_at"),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Blog Posts table
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  excerpt: text("excerpt").notNull(),
  body: text("body").notNull(),
  coverImage: varchar("cover_image", { length: 500 }),
  tags: json("tags").$type<string[]>().default([]),
  status: mysqlEnum("status", ["draft", "published"]).notNull().default("draft"),
  publishedAt: datetime("published_at"),
  authorId: int("author_id").notNull(),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").default(sql`CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`),
});

// Team Members table
export const teamMembers = mysqlTable("team_members", {
  id: int("id").primaryKey().autoincrement(),
  name: varchar("name", { length: 255 }).notNull(),
  roleType: mysqlEnum("role_type", ["officer", "agent"]).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 50 }).notNull(),
  email: varchar("email", { length: 255 }),
  photoUrl: varchar("photo_url", { length: 500 }),
  order: int("order").default(0),
  specialization: varchar("specialization", { length: 255 }),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Leads table
export const leads = mysqlTable("leads", {
  id: int("id").primaryKey().autoincrement(),
  type: mysqlEnum("type", ["contact", "schedule"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  message: text("message").notNull(),
  propertyId: int("property_id"),
  preferredTime: datetime("preferred_time"),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Hero Slides table
export const heroSlides = mysqlTable("hero_slides", {
  id: int("id").primaryKey().autoincrement(),
  title: varchar("title", { length: 500 }).notNull(),
  subtitle: varchar("subtitle", { length: 1000 }).notNull(),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  ctaText: varchar("cta_text", { length: 255 }),
  ctaLink: varchar("cta_link", { length: 500 }),
  order: int("order").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").default(sql`CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`),
});

// Settings table
export const settings = mysqlTable("settings", {
  id: int("id").primaryKey().autoincrement(),
  phoneNumber: varchar("phone_number", { length: 50 }).default("0974408281"),
  whatsappNumber: varchar("whatsapp_number", { length: 50 }).default("0974408281"),
  email: varchar("email", { length: 255 }),
  supportEmail: varchar("support_email", { length: 255 }),
  address: json("address").$type<{
    street?: string;
    city?: string;
    region?: string;
    country?: string;
    postalCode?: string;
  }>().default({}),
  businessHours: json("business_hours").$type<{
    monday?: string;
    tuesday?: string;
    wednesday?: string;
    thursday?: string;
    friday?: string;
    saturday?: string;
    sunday?: string;
  }>().default({}),
  hotlineNumbers: json("hotline_numbers").$type<string[]>().default([]),
  socialLinks: json("social_links").$type<{
    facebook?: string;
    youtube?: string;
    instagram?: string;
    twitter?: string;
    linkedin?: string;
    telegram?: string;
  }>().default({}),
  whatsappTemplate: text("whatsapp_template").default("I'm interested in {propertyTitle} - {propertyPrice}. Property link: {propertyLink}"),
  seoDefaults: json("seo_defaults").$type<{
    title?: string;
    description?: string;
    keywords?: string;
  }>().default({}),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").default(sql`CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`),
});

// Zod schemas for MySQL tables
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertPropertySchema = createInsertSchema(properties).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertConstructionUpdateSchema = createInsertSchema(constructionUpdates).omit({ id: true, createdAt: true });
export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({ id: true, createdAt: true });
export const insertLeadSchema = createInsertSchema(leads).omit({ id: true, createdAt: true });
export const insertHeroSlideSchema = createInsertSchema(heroSlides).omit({ id: true, createdAt: true, updatedAt: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true, createdAt: true, updatedAt: true });

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Property = typeof properties.$inferSelect;
export type InsertProperty = typeof properties.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type ConstructionUpdate = typeof constructionUpdates.$inferSelect;
export type InsertConstructionUpdate = typeof constructionUpdates.$inferInsert;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;
export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = typeof teamMembers.$inferInsert;
export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;
export type HeroSlide = typeof heroSlides.$inferSelect;
export type InsertHeroSlide = typeof heroSlides.$inferInsert;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = typeof settings.$inferInsert;